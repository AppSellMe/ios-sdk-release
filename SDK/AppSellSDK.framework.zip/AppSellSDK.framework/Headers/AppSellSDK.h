//
//  AppSellSDK.h
//  AppSellSDK
//
//  Created by Mikhail Igonin on 16.07.2018.
//  Copyright © 2018 Mikhail Igonin. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for AppSellSDK.
FOUNDATION_EXPORT double AppSellSDKVersionNumber;

//! Project version string for AppSellSDK.
FOUNDATION_EXPORT const unsigned char AppSellSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AppSellSDK/PublicHeader.h>


